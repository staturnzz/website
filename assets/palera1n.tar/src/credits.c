#include <stdio.h>

#ifndef BAKERAIN_DEVELOPE_R
#define BAKERAIN_DEVELOPE_R "dora2ios"
#endif
#define THE_PLUSH "Ploosh"

#define T void
#define R print_credits(void) {
#define O fprintf
#define U (
#define B stderr
#define L ,
#define E "# == palera1n-c == \n#\n"
#define M "# Made by: Nick Chan, " THE_PLUSH ", Mineek, Nebula, llsc12\n#\n"
#define A "# Thanks to: " BAKERAIN_DEVELOPE_R ", pythonplayer, tihmstar, nikias\n"
#define K "# (libimobiledevice), checkra1n team (Siguza, axi0mx, littlelailo\n"
#define I "# et al.), Procursus Team (Hayden Seay, Cameron Katri, Keto et.al)\n\n"
#define N )
#define G ;
#define S }

T R O U B L E M A K I N G S
