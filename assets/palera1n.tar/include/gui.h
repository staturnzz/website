#ifndef GUI_H
#define GUI_H

#define ASSET_DIR "assets/"

int palera1n(int argc, char *argv[]);

#endif /* gui.h */
